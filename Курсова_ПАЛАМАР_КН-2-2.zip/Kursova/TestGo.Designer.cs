﻿namespace Kursova
{
    partial class TestGo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TestGo));
            this.panel_header = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.X = new System.Windows.Forms.Panel();
            this.XIcon = new System.Windows.Forms.PictureBox();
            this.panel = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Lquestion = new System.Windows.Forms.Label();
            this.p2 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.p2_r4 = new System.Windows.Forms.ComboBox();
            this.p2_r3 = new System.Windows.Forms.ComboBox();
            this.p2_r2 = new System.Windows.Forms.ComboBox();
            this.p2_r1 = new System.Windows.Forms.ComboBox();
            this.p2_t4 = new System.Windows.Forms.Label();
            this.p2_t3 = new System.Windows.Forms.Label();
            this.p2_t2 = new System.Windows.Forms.Label();
            this.p2_t1 = new System.Windows.Forms.Label();
            this.p3 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.p3_t4 = new System.Windows.Forms.CheckBox();
            this.p3_t3 = new System.Windows.Forms.CheckBox();
            this.p3_t2 = new System.Windows.Forms.CheckBox();
            this.p3_t1 = new System.Windows.Forms.CheckBox();
            this.p1 = new System.Windows.Forms.Panel();
            this.p1_t4 = new System.Windows.Forms.Button();
            this.p1_t3 = new System.Windows.Forms.Button();
            this.p1_t2 = new System.Windows.Forms.Button();
            this.p1_t1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.panel_header.SuspendLayout();
            this.X.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.XIcon)).BeginInit();
            this.panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.p2.SuspendLayout();
            this.p3.SuspendLayout();
            this.p1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_header
            // 
            this.panel_header.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(185)))), ((int)(((byte)(132)))));
            this.panel_header.Controls.Add(this.label1);
            this.panel_header.Controls.Add(this.X);
            this.panel_header.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_header.Location = new System.Drawing.Point(0, 0);
            this.panel_header.Name = "panel_header";
            this.panel_header.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.panel_header.Size = new System.Drawing.Size(800, 24);
            this.panel_header.TabIndex = 2;
            this.panel_header.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_header_MouseDown);
            this.panel_header.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel_header_MouseMove);
            this.panel_header.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel_header_MouseUp);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Enabled = false;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "Тестування ";
            // 
            // X
            // 
            this.X.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(185)))), ((int)(((byte)(132)))));
            this.X.Controls.Add(this.XIcon);
            this.X.Location = new System.Drawing.Point(776, 0);
            this.X.Name = "X";
            this.X.Padding = new System.Windows.Forms.Padding(2);
            this.X.Size = new System.Drawing.Size(24, 24);
            this.X.TabIndex = 3;
            this.X.Click += new System.EventHandler(this.X_Click);
            this.X.MouseEnter += new System.EventHandler(this.X_MouseEnter);
            this.X.MouseLeave += new System.EventHandler(this.X_MouseLeave);
            // 
            // XIcon
            // 
            this.XIcon.BackColor = System.Drawing.Color.Transparent;
            this.XIcon.Dock = System.Windows.Forms.DockStyle.Fill;
            this.XIcon.Enabled = false;
            this.XIcon.Image = global::Kursova.Properties.Resources.X_icon;
            this.XIcon.Location = new System.Drawing.Point(2, 2);
            this.XIcon.Margin = new System.Windows.Forms.Padding(0);
            this.XIcon.Name = "XIcon";
            this.XIcon.Size = new System.Drawing.Size(20, 20);
            this.XIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.XIcon.TabIndex = 4;
            this.XIcon.TabStop = false;
            // 
            // panel
            // 
            this.panel.AutoScroll = true;
            this.panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(185)))), ((int)(((byte)(132)))));
            this.panel.Controls.Add(this.pictureBox1);
            this.panel.Controls.Add(this.Lquestion);
            this.panel.Location = new System.Drawing.Point(27, 58);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(746, 275);
            this.panel.TabIndex = 8;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(0, 83);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(745, 192);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            this.pictureBox1.LoadCompleted += new System.ComponentModel.AsyncCompletedEventHandler(this.pictureBox1_LoadCompleted);
            // 
            // Lquestion
            // 
            this.Lquestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lquestion.Location = new System.Drawing.Point(0, 0);
            this.Lquestion.Name = "Lquestion";
            this.Lquestion.Padding = new System.Windows.Forms.Padding(16);
            this.Lquestion.Size = new System.Drawing.Size(746, 275);
            this.Lquestion.TabIndex = 0;
            this.Lquestion.Text = "Question";
            this.Lquestion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Lquestion.UseMnemonic = false;
            // 
            // p2
            // 
            this.p2.Controls.Add(this.button2);
            this.p2.Controls.Add(this.p2_r4);
            this.p2.Controls.Add(this.p2_r3);
            this.p2.Controls.Add(this.p2_r2);
            this.p2.Controls.Add(this.p2_r1);
            this.p2.Controls.Add(this.p2_t4);
            this.p2.Controls.Add(this.p2_t3);
            this.p2.Controls.Add(this.p2_t2);
            this.p2.Controls.Add(this.p2_t1);
            this.p2.Location = new System.Drawing.Point(31, 613);
            this.p2.Name = "p2";
            this.p2.Size = new System.Drawing.Size(746, 271);
            this.p2.TabIndex = 22;
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.Location = new System.Drawing.Point(0, 214);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(241, 54);
            this.button2.TabIndex = 23;
            this.button2.Text = "Відповісти";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // p2_r4
            // 
            this.p2_r4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.p2_r4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.p2_r4.FormattingEnabled = true;
            this.p2_r4.Location = new System.Drawing.Point(263, 164);
            this.p2_r4.Name = "p2_r4";
            this.p2_r4.Size = new System.Drawing.Size(480, 32);
            this.p2_r4.TabIndex = 7;
            // 
            // p2_r3
            // 
            this.p2_r3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.p2_r3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.p2_r3.FormattingEnabled = true;
            this.p2_r3.Location = new System.Drawing.Point(263, 110);
            this.p2_r3.Name = "p2_r3";
            this.p2_r3.Size = new System.Drawing.Size(480, 32);
            this.p2_r3.TabIndex = 6;
            // 
            // p2_r2
            // 
            this.p2_r2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.p2_r2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.p2_r2.FormattingEnabled = true;
            this.p2_r2.Location = new System.Drawing.Point(263, 58);
            this.p2_r2.Name = "p2_r2";
            this.p2_r2.Size = new System.Drawing.Size(480, 32);
            this.p2_r2.TabIndex = 5;
            // 
            // p2_r1
            // 
            this.p2_r1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.p2_r1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.p2_r1.FormattingEnabled = true;
            this.p2_r1.Location = new System.Drawing.Point(263, 6);
            this.p2_r1.Name = "p2_r1";
            this.p2_r1.Size = new System.Drawing.Size(480, 32);
            this.p2_r1.TabIndex = 4;
            // 
            // p2_t4
            // 
            this.p2_t4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p2_t4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.p2_t4.Location = new System.Drawing.Point(0, 158);
            this.p2_t4.Name = "p2_t4";
            this.p2_t4.Size = new System.Drawing.Size(241, 42);
            this.p2_t4.TabIndex = 3;
            this.p2_t4.Text = "label2";
            this.p2_t4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // p2_t3
            // 
            this.p2_t3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p2_t3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.p2_t3.Location = new System.Drawing.Point(0, 104);
            this.p2_t3.Name = "p2_t3";
            this.p2_t3.Size = new System.Drawing.Size(241, 42);
            this.p2_t3.TabIndex = 2;
            this.p2_t3.Text = "label2";
            this.p2_t3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // p2_t2
            // 
            this.p2_t2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p2_t2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.p2_t2.Location = new System.Drawing.Point(0, 52);
            this.p2_t2.Name = "p2_t2";
            this.p2_t2.Size = new System.Drawing.Size(241, 42);
            this.p2_t2.TabIndex = 1;
            this.p2_t2.Text = "label2";
            this.p2_t2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // p2_t1
            // 
            this.p2_t1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p2_t1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.p2_t1.Location = new System.Drawing.Point(0, 0);
            this.p2_t1.Name = "p2_t1";
            this.p2_t1.Size = new System.Drawing.Size(241, 42);
            this.p2_t1.TabIndex = 0;
            this.p2_t1.Text = "label2";
            this.p2_t1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // p3
            // 
            this.p3.Controls.Add(this.button3);
            this.p3.Controls.Add(this.p3_t4);
            this.p3.Controls.Add(this.p3_t3);
            this.p3.Controls.Add(this.p3_t2);
            this.p3.Controls.Add(this.p3_t1);
            this.p3.Location = new System.Drawing.Point(27, 792);
            this.p3.Name = "p3";
            this.p3.Size = new System.Drawing.Size(746, 200);
            this.p3.TabIndex = 21;
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button3.Location = new System.Drawing.Point(0, 0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(274, 200);
            this.button3.TabIndex = 4;
            this.button3.Text = "Відповісти";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // p3_t4
            // 
            this.p3_t4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.p3_t4.Location = new System.Drawing.Point(304, 156);
            this.p3_t4.Name = "p3_t4";
            this.p3_t4.Size = new System.Drawing.Size(439, 33);
            this.p3_t4.TabIndex = 3;
            this.p3_t4.Text = "checkBox4";
            this.p3_t4.UseVisualStyleBackColor = true;
            // 
            // p3_t3
            // 
            this.p3_t3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.p3_t3.Location = new System.Drawing.Point(304, 108);
            this.p3_t3.Name = "p3_t3";
            this.p3_t3.Size = new System.Drawing.Size(439, 33);
            this.p3_t3.TabIndex = 2;
            this.p3_t3.Text = "checkBox3";
            this.p3_t3.UseVisualStyleBackColor = true;
            // 
            // p3_t2
            // 
            this.p3_t2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.p3_t2.Location = new System.Drawing.Point(304, 59);
            this.p3_t2.Name = "p3_t2";
            this.p3_t2.Size = new System.Drawing.Size(439, 33);
            this.p3_t2.TabIndex = 1;
            this.p3_t2.Text = "checkBox2";
            this.p3_t2.UseVisualStyleBackColor = true;
            // 
            // p3_t1
            // 
            this.p3_t1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.p3_t1.Location = new System.Drawing.Point(304, 10);
            this.p3_t1.Name = "p3_t1";
            this.p3_t1.Size = new System.Drawing.Size(439, 33);
            this.p3_t1.TabIndex = 0;
            this.p3_t1.Text = "checkBox1";
            this.p3_t1.UseVisualStyleBackColor = true;
            // 
            // p1
            // 
            this.p1.Controls.Add(this.p1_t4);
            this.p1.Controls.Add(this.p1_t3);
            this.p1.Controls.Add(this.p1_t2);
            this.p1.Controls.Add(this.p1_t1);
            this.p1.Location = new System.Drawing.Point(27, 387);
            this.p1.Name = "p1";
            this.p1.Size = new System.Drawing.Size(746, 200);
            this.p1.TabIndex = 20;
            // 
            // p1_t4
            // 
            this.p1_t4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.p1_t4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.p1_t4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.p1_t4.Location = new System.Drawing.Point(412, 121);
            this.p1_t4.Name = "p1_t4";
            this.p1_t4.Size = new System.Drawing.Size(334, 79);
            this.p1_t4.TabIndex = 3;
            this.p1_t4.TabStop = false;
            this.p1_t4.Text = "button4";
            this.p1_t4.UseVisualStyleBackColor = false;
            this.p1_t4.Click += new System.EventHandler(this.p1_t4_Click);
            // 
            // p1_t3
            // 
            this.p1_t3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.p1_t3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.p1_t3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.p1_t3.Location = new System.Drawing.Point(0, 121);
            this.p1_t3.Name = "p1_t3";
            this.p1_t3.Size = new System.Drawing.Size(334, 79);
            this.p1_t3.TabIndex = 2;
            this.p1_t3.TabStop = false;
            this.p1_t3.Text = "button3";
            this.p1_t3.UseVisualStyleBackColor = false;
            this.p1_t3.Click += new System.EventHandler(this.p1_t3_Click);
            // 
            // p1_t2
            // 
            this.p1_t2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.p1_t2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.p1_t2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.p1_t2.Location = new System.Drawing.Point(412, 0);
            this.p1_t2.Name = "p1_t2";
            this.p1_t2.Size = new System.Drawing.Size(334, 79);
            this.p1_t2.TabIndex = 1;
            this.p1_t2.TabStop = false;
            this.p1_t2.Text = "button2";
            this.p1_t2.UseVisualStyleBackColor = false;
            this.p1_t2.Click += new System.EventHandler(this.p1_t2_Click);
            // 
            // p1_t1
            // 
            this.p1_t1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.p1_t1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.p1_t1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.p1_t1.Location = new System.Drawing.Point(0, 0);
            this.p1_t1.Name = "p1_t1";
            this.p1_t1.Size = new System.Drawing.Size(334, 79);
            this.p1_t1.TabIndex = 0;
            this.p1_t1.TabStop = false;
            this.p1_t1.Text = "button1";
            this.p1_t1.UseVisualStyleBackColor = false;
            this.p1_t1.Click += new System.EventHandler(this.p1_t1_Click);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(27, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(745, 31);
            this.label2.TabIndex = 23;
            this.label2.Text = "NAME";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TestGo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(253)))), ((int)(((byte)(225)))));
            this.ClientSize = new System.Drawing.Size(800, 625);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.p2);
            this.Controls.Add(this.p3);
            this.Controls.Add(this.p1);
            this.Controls.Add(this.panel);
            this.Controls.Add(this.panel_header);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.ImeMode = System.Windows.Forms.ImeMode.On;
            this.Name = "TestGo";
            this.Text = "Тестування";
            this.panel_header.ResumeLayout(false);
            this.panel_header.PerformLayout();
            this.X.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.XIcon)).EndInit();
            this.panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.p2.ResumeLayout(false);
            this.p3.ResumeLayout(false);
            this.p1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel_header;
        private System.Windows.Forms.Panel X;
        private System.Windows.Forms.PictureBox XIcon;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.Panel p2;
        private System.Windows.Forms.Panel p3;
        private System.Windows.Forms.Panel p1;
        private System.Windows.Forms.Button p1_t4;
        private System.Windows.Forms.Button p1_t3;
        private System.Windows.Forms.Button p1_t2;
        private System.Windows.Forms.Button p1_t1;
        private System.Windows.Forms.Label Lquestion;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label p2_t4;
        private System.Windows.Forms.Label p2_t3;
        private System.Windows.Forms.Label p2_t2;
        private System.Windows.Forms.Label p2_t1;
        private System.Windows.Forms.ComboBox p2_r4;
        private System.Windows.Forms.ComboBox p2_r3;
        private System.Windows.Forms.ComboBox p2_r2;
        private System.Windows.Forms.ComboBox p2_r1;
        private System.Windows.Forms.CheckBox p3_t1;
        private System.Windows.Forms.CheckBox p3_t4;
        private System.Windows.Forms.CheckBox p3_t3;
        private System.Windows.Forms.CheckBox p3_t2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label2;
    }
}

