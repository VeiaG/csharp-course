﻿namespace Kursova
{
    partial class NewQ
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
            System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
            System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NewQ));
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.p1_r1 = new System.Windows.Forms.RadioButton();
            this.p1_t1 = new System.Windows.Forms.TextBox();
            this.p1_r2 = new System.Windows.Forms.RadioButton();
            this.p1_t2 = new System.Windows.Forms.TextBox();
            this.p1_r3 = new System.Windows.Forms.RadioButton();
            this.p1_t3 = new System.Windows.Forms.TextBox();
            this.p1_r4 = new System.Windows.Forms.RadioButton();
            this.p1_t4 = new System.Windows.Forms.TextBox();
            this.p3_r4 = new System.Windows.Forms.CheckBox();
            this.p3_r3 = new System.Windows.Forms.CheckBox();
            this.p3_r2 = new System.Windows.Forms.CheckBox();
            this.p3_r1 = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.p3_t1 = new System.Windows.Forms.TextBox();
            this.p3_t2 = new System.Windows.Forms.TextBox();
            this.p3_t3 = new System.Windows.Forms.TextBox();
            this.p3_t4 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.p2_t1 = new System.Windows.Forms.TextBox();
            this.p2_t2 = new System.Windows.Forms.TextBox();
            this.p2_r1 = new System.Windows.Forms.TextBox();
            this.p2_r2 = new System.Windows.Forms.TextBox();
            this.p2_r3 = new System.Windows.Forms.TextBox();
            this.p2_t4 = new System.Windows.Forms.TextBox();
            this.p2_r4 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.p2_t3 = new System.Windows.Forms.TextBox();
            this.panel_header = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.X = new System.Windows.Forms.Panel();
            this.XIcon = new System.Windows.Forms.PictureBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.urlT = new System.Windows.Forms.TextBox();
            this.p1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.p3 = new System.Windows.Forms.Panel();
            this.p2 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            tableLayoutPanel1.SuspendLayout();
            tableLayoutPanel2.SuspendLayout();
            tableLayoutPanel3.SuspendLayout();
            this.panel_header.SuspendLayout();
            this.X.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.XIcon)).BeginInit();
            this.p1.SuspendLayout();
            this.p3.SuspendLayout();
            this.p2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.AllowDrop = true;
            tableLayoutPanel1.ColumnCount = 3;
            tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4.948453F));
            tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 84.74227F));
            tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.51546F));
            tableLayoutPanel1.Controls.Add(this.label6, 0, 1);
            tableLayoutPanel1.Controls.Add(this.label5, 0, 0);
            tableLayoutPanel1.Controls.Add(this.label8, 0, 3);
            tableLayoutPanel1.Controls.Add(this.label7, 0, 2);
            tableLayoutPanel1.Controls.Add(this.p1_r1, 2, 0);
            tableLayoutPanel1.Controls.Add(this.p1_t1, 1, 0);
            tableLayoutPanel1.Controls.Add(this.p1_r2, 2, 1);
            tableLayoutPanel1.Controls.Add(this.p1_t2, 1, 1);
            tableLayoutPanel1.Controls.Add(this.p1_r3, 2, 2);
            tableLayoutPanel1.Controls.Add(this.p1_t3, 1, 2);
            tableLayoutPanel1.Controls.Add(this.p1_r4, 2, 3);
            tableLayoutPanel1.Controls.Add(this.p1_t4, 1, 3);
            tableLayoutPanel1.Location = new System.Drawing.Point(3, 16);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 2;
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            tableLayoutPanel1.Size = new System.Drawing.Size(489, 113);
            tableLayoutPanel1.TabIndex = 18;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(3, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(18, 20);
            this.label6.TabIndex = 15;
            this.label6.Text = "2";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(3, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 20);
            this.label5.TabIndex = 14;
            this.label5.Text = "1";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(3, 78);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(18, 20);
            this.label8.TabIndex = 17;
            this.label8.Text = "4";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(3, 52);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(18, 20);
            this.label7.TabIndex = 16;
            this.label7.Text = "3";
            // 
            // p1_r1
            // 
            this.p1_r1.AutoSize = true;
            this.p1_r1.Location = new System.Drawing.Point(440, 3);
            this.p1_r1.Name = "p1_r1";
            this.p1_r1.Size = new System.Drawing.Size(14, 13);
            this.p1_r1.TabIndex = 0;
            this.p1_r1.TabStop = true;
            this.p1_r1.UseVisualStyleBackColor = true;
            // 
            // p1_t1
            // 
            this.p1_t1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(253)))), ((int)(((byte)(225)))));
            this.p1_t1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p1_t1.Location = new System.Drawing.Point(27, 3);
            this.p1_t1.Name = "p1_t1";
            this.p1_t1.Size = new System.Drawing.Size(404, 20);
            this.p1_t1.TabIndex = 0;
            // 
            // p1_r2
            // 
            this.p1_r2.AutoSize = true;
            this.p1_r2.Location = new System.Drawing.Point(440, 29);
            this.p1_r2.Name = "p1_r2";
            this.p1_r2.Size = new System.Drawing.Size(14, 13);
            this.p1_r2.TabIndex = 1;
            this.p1_r2.TabStop = true;
            this.p1_r2.UseVisualStyleBackColor = true;
            // 
            // p1_t2
            // 
            this.p1_t2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(253)))), ((int)(((byte)(225)))));
            this.p1_t2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p1_t2.Location = new System.Drawing.Point(27, 29);
            this.p1_t2.Name = "p1_t2";
            this.p1_t2.Size = new System.Drawing.Size(404, 20);
            this.p1_t2.TabIndex = 1;
            // 
            // p1_r3
            // 
            this.p1_r3.AutoSize = true;
            this.p1_r3.Location = new System.Drawing.Point(440, 55);
            this.p1_r3.Name = "p1_r3";
            this.p1_r3.Size = new System.Drawing.Size(14, 13);
            this.p1_r3.TabIndex = 2;
            this.p1_r3.TabStop = true;
            this.p1_r3.UseVisualStyleBackColor = true;
            // 
            // p1_t3
            // 
            this.p1_t3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(253)))), ((int)(((byte)(225)))));
            this.p1_t3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p1_t3.Location = new System.Drawing.Point(27, 55);
            this.p1_t3.Name = "p1_t3";
            this.p1_t3.Size = new System.Drawing.Size(404, 20);
            this.p1_t3.TabIndex = 2;
            // 
            // p1_r4
            // 
            this.p1_r4.AutoSize = true;
            this.p1_r4.Location = new System.Drawing.Point(440, 81);
            this.p1_r4.Name = "p1_r4";
            this.p1_r4.Size = new System.Drawing.Size(14, 13);
            this.p1_r4.TabIndex = 3;
            this.p1_r4.TabStop = true;
            this.p1_r4.UseVisualStyleBackColor = true;
            // 
            // p1_t4
            // 
            this.p1_t4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(253)))), ((int)(((byte)(225)))));
            this.p1_t4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p1_t4.Location = new System.Drawing.Point(27, 81);
            this.p1_t4.Name = "p1_t4";
            this.p1_t4.Size = new System.Drawing.Size(404, 20);
            this.p1_t4.TabIndex = 3;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.AllowDrop = true;
            tableLayoutPanel2.ColumnCount = 3;
            tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4.948453F));
            tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 84.74227F));
            tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.51546F));
            tableLayoutPanel2.Controls.Add(this.p3_r4, 2, 3);
            tableLayoutPanel2.Controls.Add(this.p3_r3, 2, 2);
            tableLayoutPanel2.Controls.Add(this.p3_r2, 2, 1);
            tableLayoutPanel2.Controls.Add(this.p3_r1, 2, 0);
            tableLayoutPanel2.Controls.Add(this.label9, 0, 1);
            tableLayoutPanel2.Controls.Add(this.label10, 0, 0);
            tableLayoutPanel2.Controls.Add(this.label11, 0, 3);
            tableLayoutPanel2.Controls.Add(this.label12, 0, 2);
            tableLayoutPanel2.Controls.Add(this.p3_t1, 1, 0);
            tableLayoutPanel2.Controls.Add(this.p3_t2, 1, 1);
            tableLayoutPanel2.Controls.Add(this.p3_t3, 1, 2);
            tableLayoutPanel2.Controls.Add(this.p3_t4, 1, 3);
            tableLayoutPanel2.Location = new System.Drawing.Point(3, 16);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 2;
            tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            tableLayoutPanel2.Size = new System.Drawing.Size(489, 113);
            tableLayoutPanel2.TabIndex = 18;
            // 
            // p3_r4
            // 
            this.p3_r4.AutoSize = true;
            this.p3_r4.Location = new System.Drawing.Point(440, 81);
            this.p3_r4.Name = "p3_r4";
            this.p3_r4.Size = new System.Drawing.Size(15, 14);
            this.p3_r4.TabIndex = 20;
            this.p3_r4.UseVisualStyleBackColor = true;
            // 
            // p3_r3
            // 
            this.p3_r3.AutoSize = true;
            this.p3_r3.Location = new System.Drawing.Point(440, 55);
            this.p3_r3.Name = "p3_r3";
            this.p3_r3.Size = new System.Drawing.Size(15, 14);
            this.p3_r3.TabIndex = 19;
            this.p3_r3.UseVisualStyleBackColor = true;
            // 
            // p3_r2
            // 
            this.p3_r2.AutoSize = true;
            this.p3_r2.Location = new System.Drawing.Point(440, 29);
            this.p3_r2.Name = "p3_r2";
            this.p3_r2.Size = new System.Drawing.Size(15, 14);
            this.p3_r2.TabIndex = 18;
            this.p3_r2.UseVisualStyleBackColor = true;
            // 
            // p3_r1
            // 
            this.p3_r1.AutoSize = true;
            this.p3_r1.Location = new System.Drawing.Point(440, 3);
            this.p3_r1.Name = "p3_r1";
            this.p3_r1.Size = new System.Drawing.Size(15, 14);
            this.p3_r1.TabIndex = 15;
            this.p3_r1.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(3, 26);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(18, 20);
            this.label9.TabIndex = 15;
            this.label9.Text = "2";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(3, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(18, 20);
            this.label10.TabIndex = 14;
            this.label10.Text = "1";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(3, 78);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(18, 20);
            this.label11.TabIndex = 17;
            this.label11.Text = "4";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(3, 52);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(18, 20);
            this.label12.TabIndex = 16;
            this.label12.Text = "3";
            // 
            // p3_t1
            // 
            this.p3_t1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(253)))), ((int)(((byte)(225)))));
            this.p3_t1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p3_t1.Location = new System.Drawing.Point(27, 3);
            this.p3_t1.Name = "p3_t1";
            this.p3_t1.Size = new System.Drawing.Size(404, 20);
            this.p3_t1.TabIndex = 0;
            // 
            // p3_t2
            // 
            this.p3_t2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(253)))), ((int)(((byte)(225)))));
            this.p3_t2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p3_t2.Location = new System.Drawing.Point(27, 29);
            this.p3_t2.Name = "p3_t2";
            this.p3_t2.Size = new System.Drawing.Size(404, 20);
            this.p3_t2.TabIndex = 1;
            // 
            // p3_t3
            // 
            this.p3_t3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(253)))), ((int)(((byte)(225)))));
            this.p3_t3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p3_t3.Location = new System.Drawing.Point(27, 55);
            this.p3_t3.Name = "p3_t3";
            this.p3_t3.Size = new System.Drawing.Size(404, 20);
            this.p3_t3.TabIndex = 2;
            // 
            // p3_t4
            // 
            this.p3_t4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(253)))), ((int)(((byte)(225)))));
            this.p3_t4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p3_t4.Location = new System.Drawing.Point(27, 81);
            this.p3_t4.Name = "p3_t4";
            this.p3_t4.Size = new System.Drawing.Size(404, 20);
            this.p3_t4.TabIndex = 4;
            // 
            // tableLayoutPanel3
            // 
            tableLayoutPanel3.AllowDrop = true;
            tableLayoutPanel3.ColumnCount = 3;
            tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4.948453F));
            tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 51.21951F));
            tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.90244F));
            tableLayoutPanel3.Controls.Add(this.label13, 0, 1);
            tableLayoutPanel3.Controls.Add(this.label14, 0, 0);
            tableLayoutPanel3.Controls.Add(this.label16, 0, 2);
            tableLayoutPanel3.Controls.Add(this.p2_t1, 1, 0);
            tableLayoutPanel3.Controls.Add(this.p2_t2, 1, 1);
            tableLayoutPanel3.Controls.Add(this.p2_r1, 2, 0);
            tableLayoutPanel3.Controls.Add(this.p2_r2, 2, 1);
            tableLayoutPanel3.Controls.Add(this.p2_r3, 2, 2);
            tableLayoutPanel3.Controls.Add(this.p2_t4, 1, 3);
            tableLayoutPanel3.Controls.Add(this.p2_r4, 1, 3);
            tableLayoutPanel3.Controls.Add(this.label15, 0, 3);
            tableLayoutPanel3.Controls.Add(this.p2_t3, 1, 2);
            tableLayoutPanel3.Location = new System.Drawing.Point(3, 16);
            tableLayoutPanel3.Name = "tableLayoutPanel3";
            tableLayoutPanel3.RowCount = 4;
            tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            tableLayoutPanel3.Size = new System.Drawing.Size(434, 113);
            tableLayoutPanel3.TabIndex = 18;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.Location = new System.Drawing.Point(3, 26);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(15, 20);
            this.label13.TabIndex = 15;
            this.label13.Text = "2";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.Location = new System.Drawing.Point(3, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(15, 20);
            this.label14.TabIndex = 14;
            this.label14.Text = "1";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.Location = new System.Drawing.Point(3, 52);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(15, 20);
            this.label16.TabIndex = 16;
            this.label16.Text = "3";
            // 
            // p2_t1
            // 
            this.p2_t1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(253)))), ((int)(((byte)(225)))));
            this.p2_t1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p2_t1.Location = new System.Drawing.Point(24, 3);
            this.p2_t1.Name = "p2_t1";
            this.p2_t1.Size = new System.Drawing.Size(206, 20);
            this.p2_t1.TabIndex = 0;
            // 
            // p2_t2
            // 
            this.p2_t2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(253)))), ((int)(((byte)(225)))));
            this.p2_t2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p2_t2.Location = new System.Drawing.Point(24, 29);
            this.p2_t2.Name = "p2_t2";
            this.p2_t2.Size = new System.Drawing.Size(206, 20);
            this.p2_t2.TabIndex = 1;
            // 
            // p2_r1
            // 
            this.p2_r1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(253)))), ((int)(((byte)(225)))));
            this.p2_r1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p2_r1.Location = new System.Drawing.Point(246, 3);
            this.p2_r1.Name = "p2_r1";
            this.p2_r1.Size = new System.Drawing.Size(185, 20);
            this.p2_r1.TabIndex = 0;
            // 
            // p2_r2
            // 
            this.p2_r2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(253)))), ((int)(((byte)(225)))));
            this.p2_r2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p2_r2.Location = new System.Drawing.Point(246, 29);
            this.p2_r2.Name = "p2_r2";
            this.p2_r2.Size = new System.Drawing.Size(185, 20);
            this.p2_r2.TabIndex = 1;
            // 
            // p2_r3
            // 
            this.p2_r3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(253)))), ((int)(((byte)(225)))));
            this.p2_r3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p2_r3.Location = new System.Drawing.Point(246, 55);
            this.p2_r3.Name = "p2_r3";
            this.p2_r3.Size = new System.Drawing.Size(185, 20);
            this.p2_r3.TabIndex = 2;
            // 
            // p2_t4
            // 
            this.p2_t4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(253)))), ((int)(((byte)(225)))));
            this.p2_t4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p2_t4.Location = new System.Drawing.Point(24, 81);
            this.p2_t4.Name = "p2_t4";
            this.p2_t4.Size = new System.Drawing.Size(206, 20);
            this.p2_t4.TabIndex = 3;
            // 
            // p2_r4
            // 
            this.p2_r4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(253)))), ((int)(((byte)(225)))));
            this.p2_r4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p2_r4.Location = new System.Drawing.Point(246, 81);
            this.p2_r4.Name = "p2_r4";
            this.p2_r4.Size = new System.Drawing.Size(185, 20);
            this.p2_r4.TabIndex = 3;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.Location = new System.Drawing.Point(3, 78);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(15, 20);
            this.label15.TabIndex = 17;
            this.label15.Text = "4";
            // 
            // p2_t3
            // 
            this.p2_t3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(253)))), ((int)(((byte)(225)))));
            this.p2_t3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p2_t3.Location = new System.Drawing.Point(24, 55);
            this.p2_t3.Name = "p2_t3";
            this.p2_t3.Size = new System.Drawing.Size(206, 20);
            this.p2_t3.TabIndex = 2;
            // 
            // panel_header
            // 
            this.panel_header.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(185)))), ((int)(((byte)(132)))));
            this.panel_header.Controls.Add(this.label1);
            this.panel_header.Controls.Add(this.X);
            this.panel_header.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_header.Location = new System.Drawing.Point(0, 0);
            this.panel_header.Name = "panel_header";
            this.panel_header.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.panel_header.Size = new System.Drawing.Size(800, 24);
            this.panel_header.TabIndex = 2;
            this.panel_header.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_header_MouseDown);
            this.panel_header.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel_header_MouseMove);
            this.panel_header.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel_header_MouseUp);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Enabled = false;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "Тестування ";
            // 
            // X
            // 
            this.X.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(185)))), ((int)(((byte)(132)))));
            this.X.Controls.Add(this.XIcon);
            this.X.Location = new System.Drawing.Point(776, 0);
            this.X.Name = "X";
            this.X.Padding = new System.Windows.Forms.Padding(2);
            this.X.Size = new System.Drawing.Size(24, 24);
            this.X.TabIndex = 3;
            this.X.Click += new System.EventHandler(this.X_Click);
            this.X.MouseEnter += new System.EventHandler(this.X_MouseEnter);
            this.X.MouseLeave += new System.EventHandler(this.X_MouseLeave);
            // 
            // XIcon
            // 
            this.XIcon.BackColor = System.Drawing.Color.Transparent;
            this.XIcon.Dock = System.Windows.Forms.DockStyle.Fill;
            this.XIcon.Enabled = false;
            this.XIcon.Image = global::Kursova.Properties.Resources.X_icon;
            this.XIcon.Location = new System.Drawing.Point(2, 2);
            this.XIcon.Margin = new System.Windows.Forms.Padding(0);
            this.XIcon.Name = "XIcon";
            this.XIcon.Size = new System.Drawing.Size(20, 20);
            this.XIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.XIcon.TabIndex = 4;
            this.XIcon.TabStop = false;
            // 
            // comboBox1
            // 
            this.comboBox1.AllowDrop = true;
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Чотири варіанти відповіді",
            "Відповідність",
            "Кілька правильних відповідей "});
            this.comboBox1.Location = new System.Drawing.Point(36, 151);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(335, 21);
            this.comboBox1.TabIndex = 3;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(297, 190);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(74, 17);
            this.checkBox1.TabIndex = 4;
            this.checkBox1.Text = "Картинка";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(253)))), ((int)(((byte)(225)))));
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Location = new System.Drawing.Point(36, 67);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(335, 54);
            this.textBox1.TabIndex = 5;
            // 
            // urlT
            // 
            this.urlT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(253)))), ((int)(((byte)(225)))));
            this.urlT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.urlT.Location = new System.Drawing.Point(84, 188);
            this.urlT.Name = "urlT";
            this.urlT.Size = new System.Drawing.Size(207, 20);
            this.urlT.TabIndex = 7;
            // 
            // p1
            // 
            this.p1.Controls.Add(tableLayoutPanel1);
            this.p1.Location = new System.Drawing.Point(36, 229);
            this.p1.Name = "p1";
            this.p1.Size = new System.Drawing.Size(515, 144);
            this.p1.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(36, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 20);
            this.label2.TabIndex = 11;
            this.label2.Text = "Запитання";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(36, 190);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 20);
            this.label3.TabIndex = 12;
            this.label3.Text = "URL";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(36, 128);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 20);
            this.label4.TabIndex = 13;
            this.label4.Text = "Тип питання";
            // 
            // p3
            // 
            this.p3.Controls.Add(tableLayoutPanel2);
            this.p3.Location = new System.Drawing.Point(36, 543);
            this.p3.Name = "p3";
            this.p3.Size = new System.Drawing.Size(515, 144);
            this.p3.TabIndex = 14;
            // 
            // p2
            // 
            this.p2.Controls.Add(tableLayoutPanel3);
            this.p2.Location = new System.Drawing.Point(36, 379);
            this.p2.Name = "p2";
            this.p2.Size = new System.Drawing.Size(515, 144);
            this.p2.TabIndex = 19;
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(619, 237);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(144, 76);
            this.button1.TabIndex = 20;
            this.button1.Text = "Додати питання";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(619, 319);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(144, 31);
            this.button2.TabIndex = 21;
            this.button2.Text = "Назад";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(398, 44);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(365, 166);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.LoadCompleted += new System.ComponentModel.AsyncCompletedEventHandler(this.pictureBox1_LoadCompleted);
            // 
            // NewQ
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(253)))), ((int)(((byte)(225)))));
            this.ClientSize = new System.Drawing.Size(800, 377);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.p2);
            this.Controls.Add(this.p3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.p1);
            this.Controls.Add(this.urlT);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.panel_header);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.ImeMode = System.Windows.Forms.ImeMode.On;
            this.Name = "NewQ";
            this.Text = "Тестування";
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel2.PerformLayout();
            tableLayoutPanel3.ResumeLayout(false);
            tableLayoutPanel3.PerformLayout();
            this.panel_header.ResumeLayout(false);
            this.panel_header.PerformLayout();
            this.X.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.XIcon)).EndInit();
            this.p1.ResumeLayout(false);
            this.p3.ResumeLayout(false);
            this.p2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel_header;
        private System.Windows.Forms.Panel X;
        private System.Windows.Forms.PictureBox XIcon;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox urlT;
        private System.Windows.Forms.Panel p1;
        private System.Windows.Forms.TextBox p1_t4;
        private System.Windows.Forms.RadioButton p1_r4;
        private System.Windows.Forms.RadioButton p1_r3;
        private System.Windows.Forms.RadioButton p1_r2;
        private System.Windows.Forms.RadioButton p1_r1;
        private System.Windows.Forms.TextBox p1_t3;
        private System.Windows.Forms.TextBox p1_t2;
        private System.Windows.Forms.TextBox p1_t1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel p3;
        private System.Windows.Forms.CheckBox p3_r4;
        private System.Windows.Forms.CheckBox p3_r3;
        private System.Windows.Forms.CheckBox p3_r2;
        private System.Windows.Forms.CheckBox p3_r1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox p3_t1;
        private System.Windows.Forms.TextBox p3_t2;
        private System.Windows.Forms.TextBox p3_t3;
        private System.Windows.Forms.TextBox p3_t4;
        private System.Windows.Forms.Panel p2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox p2_t1;
        private System.Windows.Forms.TextBox p2_t2;
        private System.Windows.Forms.TextBox p2_r1;
        private System.Windows.Forms.TextBox p2_r2;
        private System.Windows.Forms.TextBox p2_r4;
        private System.Windows.Forms.TextBox p2_r3;
        private System.Windows.Forms.TextBox p2_t4;
        private System.Windows.Forms.TextBox p2_t3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}

